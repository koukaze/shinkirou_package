def print_name():
    print("Kou Kaze")

def age():
    print("81")