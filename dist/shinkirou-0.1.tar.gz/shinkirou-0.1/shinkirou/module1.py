def print_name():
    print("Koukaze")

def age():
    print("18")